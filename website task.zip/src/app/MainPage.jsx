// src/pages/ClientRegister.js
import React, { useState } from 'react';

import './login.css';

const Register = () => {
  

  return (
    <div className="container">
      <div className="left-half"><img src="/j3.jpg" alt="Client Image" /></div>
      <div className="right-half">
        <h2>Client Register</h2>
       </div>
    </div>
  );
};

export default Register;
